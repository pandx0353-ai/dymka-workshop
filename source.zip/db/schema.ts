import { integer, index, sqliteTable, text } from "drizzle-orm/sqlite-core";

export const accounts = sqliteTable("accounts", {
  userId: text("user_id").primaryKey(),
  email: text("email").notNull().default(""),
  displayName: text("display_name").notNull().default("Мастер"),
  profileJson: text("profile_json").notNull(),
  favoritesJson: text("favorites_json").notNull().default("[]"),
  updatedAt: integer("updated_at", { mode: "timestamp_ms" }).notNull(),
});

export const savedToys = sqliteTable("saved_toys", {
  id: text("id").primaryKey(),
  userId: text("user_id").notNull(),
  toyJson: text("toy_json").notNull(),
  imageKey: text("image_key"),
  createdAt: integer("created_at", { mode: "timestamp_ms" }).notNull(),
}, (table) => [index("saved_toys_user_id_idx").on(table.userId)]);
