"""Build local, textured 2.5D glTF models for the app's transparent toy art.

Run with: blender -b --python scripts/generate-ar-models.py
The source artwork remains on-device; model-viewer swaps its front texture at runtime.
"""
import os
import bpy

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ASSET_DIR = os.path.join(ROOT, "public", "assets")
OUT_DIR = os.path.join(ASSET_DIR, "ar")
os.makedirs(OUT_DIR, exist_ok=True)

SOURCES = {
    "lady": "lady.png",
    "clay-lady": "clay-lady.png",
    "clay-lady2": "clay-lady2.png",
    "man": "man.png",
    "clay-man": "clay-man.png",
    "accordion": "accordion.png",
    "rooster": "rooster.png",
    "clay-rooster": "clay-rooster.png",
    "goat": "goat.png",
    "horse": "horse.png",
    "clay-horse": "clay-horse.png",
    "deer": "deer.png",
}

def clear_scene():
    bpy.ops.object.select_all(action="SELECT")
    bpy.ops.object.delete(use_global=False)
    for datablocks in (bpy.data.meshes, bpy.data.materials, bpy.data.images, bpy.data.curves):
        for block in list(datablocks):
            if block.users == 0:
                datablocks.remove(block)

def make_art_material(image):
    material = bpy.data.materials.new("ToyArtwork")
    material.diffuse_color = (0.78, 0.36, 0.20, 1.0)
    material.use_nodes = True
    nodes = material.node_tree.nodes
    links = material.node_tree.links
    shader = nodes.get("Principled BSDF")
    texture = nodes.new("ShaderNodeTexImage")
    texture.name = "ToyArtworkTexture"
    texture.label = "Artwork texture swapped locally at runtime"
    texture.image = image
    links.new(texture.outputs["Color"], shader.inputs["Base Color"])
    links.new(texture.outputs["Alpha"], shader.inputs["Alpha"])
    shader.inputs["Roughness"].default_value = 0.72
    try:
        material.surface_render_method = "DITHERED"
    except Exception:
        pass
    return material

def make_side_material():
    material = bpy.data.materials.new("ClayEdges")
    material.diffuse_color = (0.57, 0.25, 0.15, 1.0)
    material.use_nodes = True
    shader = material.node_tree.nodes.get("Principled BSDF")
    shader.inputs["Base Color"].default_value = (0.57, 0.25, 0.15, 1.0)
    shader.inputs["Roughness"].default_value = 0.76
    return material

def make_foot(height):
    material = bpy.data.materials.new("WarmClayFoot")
    material.diffuse_color = (0.78, 0.68, 0.51, 1.0)
    material.use_nodes = True
    shader = material.node_tree.nodes.get("Principled BSDF")
    shader.inputs["Base Color"].default_value = (0.78, 0.68, 0.51, 1.0)
    shader.inputs["Roughness"].default_value = 0.72
    bpy.ops.mesh.primitive_cylinder_add(vertices=48, radius=0.5, depth=0.008, location=(0, 0, -height / 2 + 0.002))
    foot = bpy.context.object
    foot.name = "SmallRoundedDisplayFoot"
    foot.scale = (0.052, 0.034, 1)
    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
    bevel = foot.modifiers.new("Soft clay edge", "BEVEL")
    bevel.width = 0.003
    bevel.segments = 3
    foot.modifiers.new("Weighted soft normals", "WEIGHTED_NORMAL")
    foot.data.materials.append(material)

def build(name, filename):
    clear_scene()
    image_path = os.path.join(ASSET_DIR, filename)
    image = bpy.data.images.load(image_path, check_existing=False)
    image.pack()
    width_px, height_px = image.size
    pixels = image.pixels[:]

    # About 1.5 mm edge sampling for a 20 cm toy. The alpha mask gives each figure
    # its own outline, while the material receives the user's saved artwork.
    grid_h = 128
    grid_w = max(48, min(256, round(grid_h * width_px / height_px)))
    opaque = [[False] * grid_w for _ in range(grid_h)]
    for y in range(grid_h):
        sy = min(height_px - 1, int((y + 0.5) * height_px / grid_h))
        for x in range(grid_w):
            sx = min(width_px - 1, int((x + 0.5) * width_px / grid_w))
            opaque[y][x] = pixels[(sy * width_px + sx) * 4 + 3] > 0.12

    art = make_art_material(image)
    edge = make_side_material()
    verts, faces, mats, face_uvs = [], [], [], []
    height_m = 0.20
    width_m = height_m * width_px / height_px
    depth_m = min(0.026, max(0.014, width_m * 0.14))
    front_y, back_y = depth_m / 2, -depth_m / 2
    dx, dz = width_m / grid_w, height_m / grid_h

    def add_face(points, material_index, uvs=None):
        base = len(verts)
        verts.extend(points)
        faces.append(tuple(range(base, base + len(points))))
        mats.append(material_index)
        face_uvs.append(uvs or [(0, 0)] * len(points))

    for y in range(grid_h):
        z0 = -height_m / 2 + y * dz
        z1 = z0 + dz
        v0, v1 = y / grid_h, (y + 1) / grid_h
        for x in range(grid_w):
            if not opaque[y][x]:
                continue
            x0 = -width_m / 2 + x * dx
            x1 = x0 + dx
            u0, u1 = x / grid_w, (x + 1) / grid_w
            # Front faces look toward +Y; backside uses the same artwork UVs.
            add_face([(x0, front_y, z0), (x0, front_y, z1), (x1, front_y, z1), (x1, front_y, z0)], 0,
                     [(u0, v0), (u0, v1), (u1, v1), (u1, v0)])
            add_face([(x1, back_y, z0), (x1, back_y, z1), (x0, back_y, z1), (x0, back_y, z0)], 0,
                     [(u1, v0), (u1, v1), (u0, v1), (u0, v0)])
            # Close each exposed silhouette edge with a thick clay-colored wall.
            if x == 0 or not opaque[y][x - 1]:
                add_face([(x0, back_y, z0), (x0, back_y, z1), (x0, front_y, z1), (x0, front_y, z0)], 1)
            if x == grid_w - 1 or not opaque[y][x + 1]:
                add_face([(x1, back_y, z1), (x1, back_y, z0), (x1, front_y, z0), (x1, front_y, z1)], 1)
            if y == 0 or not opaque[y - 1][x]:
                add_face([(x0, back_y, z0), (x1, back_y, z0), (x1, front_y, z0), (x0, front_y, z0)], 1)
            if y == grid_h - 1 or not opaque[y + 1][x]:
                add_face([(x1, back_y, z1), (x0, back_y, z1), (x0, front_y, z1), (x1, front_y, z1)], 1)

    mesh = bpy.data.meshes.new("ExtrudedToySilhouette")
    mesh.from_pydata(verts, [], faces)
    mesh.materials.append(art)
    mesh.materials.append(edge)
    for poly, material_index in zip(mesh.polygons, mats):
        poly.material_index = material_index
    uv_layer = mesh.uv_layers.new(name="ArtworkUV")
    for poly, values in zip(mesh.polygons, face_uvs):
        for loop_index, uv in zip(poly.loop_indices, values):
            uv_layer.data[loop_index].uv = uv
    mesh.update()
    body = bpy.data.objects.new("ToyArtworkSilhouette", mesh)
    bpy.context.collection.objects.link(body)
    make_foot(height_m)

    bpy.ops.object.select_all(action="DESELECT")
    body.select_set(True)
    bpy.context.view_layer.objects.active = body
    bpy.ops.export_scene.gltf(filepath=os.path.join(OUT_DIR, "ar-" + name + ".glb"), export_format="GLB", use_selection=False, export_apply=True)
    print("Wrote AR model", name, filename, len(faces), "faces")

for model_name, artwork in SOURCES.items():
    build(model_name, artwork)
