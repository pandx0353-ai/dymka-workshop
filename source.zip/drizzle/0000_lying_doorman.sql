CREATE TABLE `accounts` (
	`user_id` text PRIMARY KEY NOT NULL,
	`email` text DEFAULT '' NOT NULL,
	`display_name` text DEFAULT 'Мастер' NOT NULL,
	`profile_json` text NOT NULL,
	`favorites_json` text DEFAULT '[]' NOT NULL,
	`updated_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `saved_toys` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`toy_json` text NOT NULL,
	`image_key` text,
	`created_at` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `saved_toys_user_id_idx` ON `saved_toys` (`user_id`);