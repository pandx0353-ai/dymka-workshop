import { env } from "cloudflare:workers";
import { getChatGPTUser } from "../../chatgpt-auth";

export const dynamic = "force-dynamic";

type SavedToy = { id: string; name?: string; image?: string; [key: string]: unknown };

export async function GET() {
  const user = await getChatGPTUser();
  if (!user) return Response.json({ authenticated: false }, { status: 401, headers: noCache });
  if (!env.DB || !env.BUCKET) return Response.json({ error: "Хранилище пока не подключено." }, { status: 503, headers: noCache });

  const account = await env.DB.prepare(
    "SELECT profile_json, favorites_json FROM accounts WHERE user_id = ?",
  ).bind(user.userId).first<{ profile_json: string; favorites_json: string }>();
  const profile = account ? parseJson(account.profile_json, {}) : { name: user.displayName, toy: "lady.png" };
  const favorites = account ? parseJson<string[]>(account.favorites_json, []) : [];
  const records = await env.DB.prepare(
    "SELECT id, toy_json, image_key FROM saved_toys WHERE user_id = ? ORDER BY created_at DESC LIMIT 30",
  ).bind(user.userId).all<{ id: string; toy_json: string; image_key: string | null }>();

  const toys = await Promise.all((records.results ?? []).map(async (record) => {
    const toy = parseJson<SavedToy>(record.toy_json, { id: record.id });
    if (record.image_key) {
      const image = await env.BUCKET.get(record.image_key);
      if (image) toy.image = `data:image/png;base64,${await toBase64(await image.arrayBuffer())}`;
    }
    return toy;
  }));

  return Response.json({ authenticated: true, id: user.userId, name: user.displayName, email: user.email, profile, favorites, toys, initialized: Boolean(account) }, { headers: noCache });
}

export async function PUT(request: Request) {
  const user = await getChatGPTUser();
  if (!user) return Response.json({ error: "Войди через аккаунт, чтобы синхронизировать мастерскую." }, { status: 401, headers: noCache });
  if (!env.DB || !env.BUCKET) return Response.json({ error: "Хранилище пока не подключено." }, { status: 503, headers: noCache });
  const length = Number(request.headers.get("content-length") ?? 0);
  if (length > 2_500_000) return Response.json({ error: "Эта игрушка слишком большая для синхронизации." }, { status: 413, headers: noCache });

  let body: { profile?: unknown; favorites?: unknown; toy?: SavedToy };
  try { body = await request.json(); } catch { return Response.json({ error: "Не удалось прочитать данные." }, { status: 400, headers: noCache }); }
  const existing = await env.DB.prepare(
    "SELECT profile_json, favorites_json FROM accounts WHERE user_id = ?",
  ).bind(user.userId).first<{ profile_json: string; favorites_json: string }>();
  const profile = body.profile === undefined ? parseJson(existing?.profile_json ?? "", { name: user.displayName, toy: "lady.png" }) : cleanProfile(body.profile, user.displayName);
  const favorites = body.favorites === undefined ? parseJson<string[]>(existing?.favorites_json ?? "[]", []) : cleanFavorites(body.favorites);
  if (!profile) return Response.json({ error: "Проверь имя профиля." }, { status: 400, headers: noCache });
  if (!favorites) return Response.json({ error: "Не получилось сохранить избранное." }, { status: 400, headers: noCache });

  await env.DB.prepare(
    "INSERT INTO accounts (user_id, email, display_name, profile_json, favorites_json, updated_at) VALUES (?, ?, ?, ?, ?, ?) ON CONFLICT(user_id) DO UPDATE SET email=excluded.email, display_name=excluded.display_name, profile_json=excluded.profile_json, favorites_json=excluded.favorites_json, updated_at=excluded.updated_at",
  ).bind(user.userId, user.email, profile.name, JSON.stringify(profile), JSON.stringify(favorites), Date.now()).run();

  if (body.toy !== undefined) {
    const saved = await storeToy(user.userId, body.toy);
    if (saved instanceof Response) return saved;
  }
  return Response.json({ ok: true }, { headers: noCache });
}

async function storeToy(userId: string, input: SavedToy): Promise<SavedToy | Response> {
  if (!input || typeof input !== "object" || !/^[A-Za-z0-9_-]{1,80}$/.test(String(input.id ?? ""))) {
    return Response.json({ error: "У игрушки не получилось сохранить ID." }, { status: 400, headers: noCache });
  }
  const toy = { ...input };
  const image = typeof toy.image === "string" ? toy.image : "";
  delete toy.image;
  const toyJson = JSON.stringify(toy);
  if (toyJson.length > 300_000) return Response.json({ error: "Слишком много данных в игрушке." }, { status: 413, headers: noCache });
  let imageKey: string | null = null;
  const prior = await env.DB.prepare("SELECT user_id, image_key FROM saved_toys WHERE id = ?").bind(String(input.id)).first<{ user_id: string; image_key: string | null }>();
  if (prior && prior.user_id !== userId) return Response.json({ error: "Эта игрушка принадлежит другому профилю." }, { status: 403, headers: noCache });
  imageKey = prior?.image_key ?? null;
  if (image.startsWith("data:image/png;base64,")) {
    try {
      const bytes = fromBase64(image.slice("data:image/png;base64,".length));
      if (!bytes.byteLength || bytes.byteLength > 1_500_000) return Response.json({ error: "Изображение игрушки слишком большое." }, { status: 413, headers: noCache });
      imageKey = `toys/${base64Url(userId)}/${input.id}.png`;
      await env.BUCKET.put(imageKey, bytes, { httpMetadata: { contentType: "image/png" } });
    } catch {
      return Response.json({ error: "Изображение игрушки не удалось сохранить." }, { status: 400, headers: noCache });
    }
  }
  await env.DB.prepare(
    "INSERT INTO saved_toys (id, user_id, toy_json, image_key, created_at) VALUES (?, ?, ?, ?, ?) ON CONFLICT(id) DO UPDATE SET toy_json=excluded.toy_json, image_key=COALESCE(excluded.image_key, saved_toys.image_key), created_at=excluded.created_at WHERE saved_toys.user_id = excluded.user_id",
  ).bind(String(input.id), userId, toyJson, imageKey, Date.now()).run();
  return toy;
}

function cleanProfile(value: unknown, fallback: string): { name: string; toy: string } | null {
  if (!value || typeof value !== "object") return null;
  const candidate = value as Record<string, unknown>;
  const name = typeof candidate.name === "string" ? candidate.name.trim().slice(0, 35) : fallback.slice(0, 35);
  const toy = typeof candidate.toy === "string" && /^[a-z0-9-]+\.png$/i.test(candidate.toy) ? candidate.toy : "lady.png";
  return name.length >= 2 ? { name, toy } : null;
}
function cleanFavorites(value: unknown): string[] | null {
  if (!Array.isArray(value) || value.length > 300 || value.some((id) => typeof id !== "string" || id.length > 100)) return null;
  return [...new Set(value)];
}
function parseJson<T>(value: string, fallback: T): T {
  try { return JSON.parse(value) as T; } catch { return fallback; }
}
function fromBase64(value: string) {
  const binary = atob(value);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes;
}
async function toBase64(buffer: ArrayBuffer) {
  const bytes = new Uint8Array(buffer);
  let output = "";
  for (let i = 0; i < bytes.length; i += 0x8000) output += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  return btoa(output);
}
function base64Url(value: string) {
  const bytes = new TextEncoder().encode(value);
  let output = "";
  for (const byte of bytes) output += String.fromCharCode(byte);
  return btoa(output).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}
const noCache = { "cache-control": "no-store" };
