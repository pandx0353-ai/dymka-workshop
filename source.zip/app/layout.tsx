import type { Metadata } from "next";
import Script from "next/script";

export const metadata: Metadata = {
  title: "Дымковская мастерская",
  description: "Лепи и расписывай дымковские игрушки, сохраняй свои работы в профиле.",
  themeColor: "#fff7e6",
  appleWebApp: { capable: true, statusBarStyle: "default", title: "Дымка" },
  manifest: "/manifest.webmanifest",
  icons: { icon: "/assets/app-192.png", apple: "/assets/app-192.png" },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="ru">
      <head>
        <meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover" />
        <link rel="stylesheet" href="/style.css" />
        <link rel="stylesheet" href="/workshop.css" />
      </head>
      <body>{children}<Script src="/assets/model-viewer.min.js" type="module" strategy="afterInteractive" /><Script src="/bootstrap.js" strategy="afterInteractive" /></body>
    </html>
  );
}
