import { headers } from "next/headers";

export const dynamic = "force-dynamic";

export default async function Home() {
  const requestHeaders = await headers();
  const accountId = requestHeaders.get("oai-authenticated-user-id") ?? "";
  const email = requestHeaders.get("oai-authenticated-user-email") ?? "";
  const encodedName = requestHeaders.get("oai-authenticated-user-full-name");
  const name = encodedName && requestHeaders.get("oai-authenticated-user-full-name-encoding") === "percent-encoded-utf-8"
    ? safeDecode(encodedName) ?? email
    : email;

  return (
    <main
      id="app"
      data-account-id={accountId}
      data-account-name={name}
      data-account-email={email}
    />
  );
}

function safeDecode(value: string) {
  try { return decodeURIComponent(value); } catch { return null; }
}
